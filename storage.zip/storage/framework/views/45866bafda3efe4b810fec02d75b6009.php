

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">

    <h2>
        
        User Management
    </h2>

    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
        
        Add User
    </a>

</div>

<?php if(session('success')): ?>

<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>

<?php endif; ?>

<?php if(session('error')): ?>

<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>

<?php endif; ?>

<div class="card shadow">

    <div class="card-body">

        <div class="d-flex justify-content-between mb-3">

            <h6>

                Total User

                <span class="badge bg-primary">

                    <?php echo e($users->count()); ?>


                </span>

            </h6>

        </div>

        <form method="GET"
              action="<?php echo e(route('users.index')); ?>"
              class="row g-2 mb-4">

            <div class="col-md-10">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Search by officer name, username or role..."
                    value="<?php echo e($keyword); ?>">

            </div>

            <div class="col-md-2">

                <button class="btn btn-primary w-100">

                    

                    Search

                </button>

            </div>

        </form>

        <table class="table table-bordered table-hover align-middle">

            <thead class="table-dark">

                <tr>

                    <th width="60">No</th>

                    <th>ID</th>

                    <th>
                        
                        Officer
                    </th>

                    <th>
                        
                        Username
                    </th>

                    <th>
                        
                        Role
                    </th>

                    <th>
                        
                        Status
                    </th>

                    <th width="220">
                        Action
                    </th>

                </tr>

            </thead>

            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>

                    <td>

                        <?php if(method_exists($users,'firstItem')): ?>

                            <?php echo e($users->firstItem() + $loop->index); ?>


                        <?php else: ?>

                            <?php echo e($loop->iteration); ?>


                        <?php endif; ?>

                    </td>

                    <td><?php echo e($user->id); ?></td>

                    <td><?php echo e($user->officer_name); ?></td>

                    <td><?php echo e($user->username); ?></td>

                    <td>

                        <?php if($user->role=='admin'): ?>

                            <span class="badge bg-danger">

                                Admin

                            </span>

                        <?php elseif($user->role=='teller'): ?>

                            <span class="badge bg-primary">

                                Teller

                            </span>

                        <?php elseif($user->role=='supervisor'): ?>

                            <span class="badge bg-danger text-white">

                                Supervisor

                            </span>

                        <?php else: ?>

                            <span class="badge bg-success">

                                Pegawai

                            </span>

                        <?php endif; ?>

                    </td>

                    <td>

                        <?php if($user->status=='aktif'): ?>

                            <span class="badge bg-success">

                                Active

                            </span>

                        <?php else: ?>

                            <span class="badge bg-danger">

                                Inactive

                            </span>

                        <?php endif; ?>

                    </td>

                    <td>

                        <a href="<?php echo e(route('users.edit',$user->id)); ?>"
                           class="btn btn-warning btn-sm">

                            

                            Edit

                        </a>

                        <form
                            action="<?php echo e(route('users.status',$user->id)); ?>"
                            method="POST"
                            class="d-inline"
                            onsubmit="return confirm('Ubah status user ini?')">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <input
                                type="hidden"
                                name="status"
                                value="<?php echo e($user->status === 'aktif' ? 'nonaktif' : 'aktif'); ?>">

                            <button
                                class="btn btn-<?php echo e($user->status === 'aktif' ? 'secondary' : 'success'); ?> btn-sm"
                                <?php echo e($user->id == auth()->id() ? 'disabled' : ''); ?>>

                                
                                <?php echo e($user->status === 'aktif' ? 'Deactivate' : 'Activate'); ?>


                            </button>

                        </form>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="7" class="text-center">

                        No user data available.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

        <?php if(method_exists($users,'links')): ?>

            <?php echo e($users->links()); ?>


        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/users/index.blade.php ENDPATH**/ ?>