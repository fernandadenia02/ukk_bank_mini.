

<?php $__env->startSection('title', 'Laporan Bulanan'); ?>

<?php $__env->startSection('content'); ?>

<h2>Laporan Bulanan</h2>
<p class="text-muted">Rekap transaksi Bank Mini berdasarkan bulan dan tahun.</p>

<hr>

<form method="GET" action="<?php echo e(route('monthly-reports.index')); ?>"
      class="card card-body shadow-sm mb-4">
    <div class="row align-items-end">
        <div class="col-md-4 mb-3">
            <label for="month" class="form-label">Bulan</label>
            <select name="month" id="month" class="form-select">
                <?php $__currentLoopData = [
                    1 => 'Januari', 2 => 'Februari', 3 => 'Maret',
                    4 => 'April', 5 => 'Mei', 6 => 'Juni',
                    7 => 'Juli', 8 => 'Agustus', 9 => 'September',
                    10 => 'Oktober', 11 => 'November', 12 => 'Desember'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($number); ?>"
                        <?php if($month == $number): echo 'selected'; endif; ?>>
                        <?php echo e($name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-4 mb-3">
            <label for="year" class="form-label">Tahun</label>
            <input type="number" name="year" id="year"
                   class="form-control"
                   min="2000" max="2100" value="<?php echo e($year); ?>" required>
        </div>

        <div class="col-md-4 mb-3">
            <button type="submit" class="btn btn-primary">
                Tampilkan Laporan
            </button>
            <button type="button" onclick="window.print()"
                    class="btn btn-secondary">
                Cetak
            </button>
        </div>
    </div>
</form>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<h5 class="mb-3">
    Periode:
    <?php echo e(\Carbon\Carbon::create($year, $month, 1)->translatedFormat('F Y')); ?>

</h5>

<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted">Jumlah Transaksi</div>
                <h4><?php echo e(number_format($summary->total_transactions ?? 0, 0, ',', '.')); ?></h4>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted">Total Setoran</div>
                <h5 class="text-success">
                    Rp <?php echo e(number_format($summary->total_deposit ?? 0, 0, ',', '.')); ?>

                </h5>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted">Total Penarikan</div>
                <h5 class="text-danger">
                    Rp <?php echo e(number_format($summary->total_withdrawals ?? 0, 0, ',', '.')); ?>

                </h5>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted">Selisih Setoran - Penarikan</div>
                <h5>
                    Rp <?php echo e(number_format(
                        ($summary->total_deposit ?? 0) -
                        ($summary->total_withdrawals ?? 0),
                        0, ',', '.'
                    )); ?>

                </h5>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-header">
        <strong>Status Daily Report</strong>
    </div>

    <div class="card-body">
        <div class="row">
            <div class="col-md-4 mb-2">
                Approved:
                <span class="badge bg-success">
                    <?php echo e($reportStatuses['approved'] ?? 0); ?>

                </span>
            </div>

            <div class="col-md-4 mb-2">
                Pending:
                <span class="badge bg-warning text-dark">
                    <?php echo e($reportStatuses['pending'] ?? 0); ?>

                </span>
            </div>

            <div class="col-md-4 mb-2">
                Rejected:
                <span class="badge bg-danger">
                    <?php echo e($reportStatuses['rejected'] ?? 0); ?>

                </span>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <strong>Rincian Transaksi Bulanan</strong>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nasabah</th>
                        <th>Teller</th>
                        <th>Jenis Transaksi</th>
                        <th>Nominal</th>
                        <th>Saldo Awal</th>
                        <th>Saldo Akhir</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php echo e($transaction->date
                                    ? \Carbon\Carbon::parse($transaction->date)->timezone('Asia/Jakarta')->format('d-m-Y H:i') . ' WIB'
                                    : '-'); ?>

                            </td>
                            <td><?php echo e($transaction->customer->name ?? '-'); ?></td>
                            <td><?php echo e($transaction->teller->officer_name ?? '-'); ?></td>
                            <td>
                                <?php if($transaction->transaction_type === 'setoran'): ?>
                                    <span class="badge bg-success">Setoran</span>
                                <?php elseif($transaction->transaction_type === 'penarikan'): ?>
                                    <span class="badge bg-danger">Penarikan</span>
                                <?php else: ?>
                                    <?php echo e($transaction->transaction_type); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                Rp <?php echo e(number_format($transaction->amount, 0, ',', '.')); ?>

                            </td>
                            <td>
                                Rp <?php echo e(number_format($transaction->beginning_balance, 0, ',', '.')); ?>

                            </td>
                            <td>
                                Rp <?php echo e(number_format($transaction->ending_balance, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">
                                Tidak ada transaksi pada periode ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    @media print {
        nav, aside, .sidebar, .btn, form {
            display: none !important;
        }

        body {
            background: white !important;
        }

        .card {
            box-shadow: none !important;
            break-inside: avoid;
        }
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/monthly_reports/index.blade.php ENDPATH**/ ?>