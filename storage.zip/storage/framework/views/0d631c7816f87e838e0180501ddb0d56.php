

<?php $__env->startSection('title', 'Naik Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h2 class="mb-1">Naik Kelas</h2>
        <p class="text-muted mb-0">
            Siswa kelas X naik ke XI, XI naik ke XII, dan XII menjadi ALUMNI.
            Centang siswa yang ingin tetap di kelas saat ini.
        </p>
    </div>
    <span class="badge bg-primary fs-6"><?php echo e($members->count()); ?> siswa dapat diproses</span>
</div>

<div class="alert alert-warning">
    <strong>Perhatian:</strong> Proses ini mengubah kelas semua siswa yang tidak dicentang.
    Akun nasabah yang menjadi alumni otomatis dinonaktifkan dan token API-nya dicabut.
</div>

<?php if($errors->has('stay_ids')): ?>
    <div class="alert alert-danger"><?php echo e($errors->first('stay_ids')); ?></div>
<?php endif; ?>

<form action="<?php echo e(route('members.promote')); ?>" method="POST"
    onsubmit="return confirm('Lanjutkan proses naik kelas untuk semua siswa yang tidak dicentang?');">
    <?php echo csrf_field(); ?>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <p class="text-muted mb-0">Siswa yang dicentang akan tetap di kelasnya.</p>
        <button type="submit" class="btn btn-primary" <?php if($members->isEmpty()): echo 'disabled'; endif; ?>>
            
            Naikkan Kelas
        </button>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas Saat Ini</th>
                    <th>Menjadi</th>
                    <th class="text-center">Tetap di kelas</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($member->nis); ?></td>
                        <td><?php echo e($member->name); ?></td>
                        <td><?php echo e($member->class); ?></td>
                        <td><?php echo e($nextClasses[$member->id]); ?></td>
                        <td class="text-center">
                            <input class="form-check-input" type="checkbox" name="stay_ids[]"
                                value="<?php echo e($member->id); ?>" aria-label="Tetapkan <?php echo e($member->name); ?> di kelas <?php echo e($member->class); ?>">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            Tidak ada siswa di kelas X, XI, atau XII yang perlu diproses.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/members/promotion.blade.php ENDPATH**/ ?>