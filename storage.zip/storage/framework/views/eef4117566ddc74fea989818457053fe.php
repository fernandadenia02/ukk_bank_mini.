


<?php $__env->startSection('title', 'Detail Daily Report'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $role = auth()->user()->role ?? '';
?>


<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2>Detail Daily Report</h2>
        <p class="text-muted mb-0">Laporan aktivitas teller</p>
    </div>

    <?php if($role === 'teller'): ?>
        <a href="<?php echo e(route('teller.dashboard')); ?>" class="btn btn-secondary">
            Kembali
        </a>
    <?php else: ?>
        <a href="<?php echo e(route('daily-reports.index')); ?>" class="btn btn-secondary">
            Kembali
        </a>
    <?php endif; ?>
</div>

<hr>


<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"
            aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"
            aria-label="Close"></button>
    </div>
<?php endif; ?>


<div class="card shadow mb-4">
    <div class="card-header bg-primary text-white">
        <strong>Informasi Daily Report</strong>
    </div>

    <div class="card-body">
        <div class="row">
            <div class="col-md-4 mb-3">
                <strong>Tanggal</strong>
                <div>
                    <?php echo e($report->date); ?>

                </div>
            </div>

            <div class="col-md-4 mb-3">
                <strong>Teller</strong>
                <div>
                    <?php echo e($report->teller->officer_name ?? '-'); ?>

                </div>
            </div>

            <div class="col-md-4 mb-3">
                <strong>Status</strong>
                <div>
                    <?php if($report->status === 'pending'): ?>
                        <span class="badge bg-warning text-dark">Pending</span>
                    <?php elseif($report->status === 'approved'): ?>
                        <span class="badge bg-success">Approved</span>
                    <?php elseif($report->status === 'rejected'): ?>
                        <span class="badge bg-danger">Rejected</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">
                            <?php echo e($report->status); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <strong>Status Kas</strong>
                <div>
                    <?php if($report->closed_at): ?>
                        <span class="badge bg-secondary">Ditutup <?php echo e($report->closed_at->timezone('Asia/Jakarta')->format('d-m-Y H:i')); ?> WIB</span>
                    <?php else: ?>
                        <span class="badge bg-warning text-dark">Belum ditutup teller</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if($report->status === 'rejected'): ?>
    <div class="card shadow mb-4 border-danger">
        <div class="card-header bg-danger text-white">
            <strong>
                
                Alasan Penolakan Daily Report
            </strong>
        </div>

        <div class="card-body">
            <?php if(filled($report->rejection_reason)): ?>
                <div class="alert alert-danger mb-0" style="white-space: pre-line;"><?php echo e($report->rejection_reason); ?></div>
            <?php else: ?>
                <div class="alert alert-warning mb-0">
                    Alasan penolakan belum tersedia pada laporan ini.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>


<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card shadow h-100">
            <div class="card-body text-center">
                <h6 class="text-muted">Total Deposit</h6>
                <h4 class="text-success">
                    Rp <?php echo e(number_format($report->total_deposit, 0, ',', '.')); ?>

                </h4>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow h-100">
            <div class="card-body text-center">
                <h6 class="text-muted">Total Withdrawal</h6>
                <h4 class="text-danger">
                    Rp <?php echo e(number_format($report->total_withdrawals, 0, ',', '.')); ?>

                </h4>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow h-100">
            <div class="card-body text-center">
                <h6 class="text-muted">Ending Balance</h6>
                <h4>
                    Rp <?php echo e(number_format($report->ending_balance, 0, ',', '.')); ?>

                </h4>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow h-100">
            <div class="card-body text-center">
                <h6 class="text-muted">Selisih</h6>
                <h4 class="<?php echo e($report->difference == 0 ? 'text-success' : 'text-danger'); ?>">
                    Rp <?php echo e(number_format($report->difference, 0, ',', '.')); ?>

                </h4>
            </div>
        </div>
    </div>
</div>


<div class="card shadow mb-4">
    <div class="card-header bg-dark text-white">
        <strong>Rekap Kas</strong>
    </div>

    <div class="card-body">
        <div class="row">
            <div class="col-md-4 mb-3">
                <strong>Modal Awal Kas</strong>
                <div>
                    Rp <?php echo e(number_format($report->beginning_balance, 0, ',', '.')); ?>

                </div>
            </div>

            <div class="col-md-4 mb-3">
                <strong>Physical Money</strong>
                <div>
                    Rp <?php echo e(number_format($report->physical_money, 0, ',', '.')); ?>

                </div>
            </div>

            <div class="col-md-4 mb-3">
                <strong>Difference</strong>
                <div>
                    <?php if($report->difference == 0): ?>
                        <span class="badge bg-success">Balance</span>
                    <?php else: ?>
                        <span class="badge bg-danger">
                            Selisih Rp <?php echo e(number_format(abs($report->difference), 0, ',', '.')); ?>

                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="card shadow mb-4">
    <div class="card-header bg-warning-subtle">
        <strong>Riwayat Permintaan Modal Kas</strong>
    </div>
    <div class="card-body">
        <?php if($cashAdvanceRequests->isNotEmpty()): ?>
            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Waktu Pengajuan</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                            <th>Diproses Oleh</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cashAdvanceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cashRequest->requested_at->timezone('Asia/Jakarta')->format('d-m-Y H:i')); ?> WIB</td>
                                <td>Rp <?php echo e(number_format($cashRequest->amount, 0, ',', '.')); ?></td>
                                <td>
                                    <?php if($cashRequest->status === 'pending'): ?>
                                        <span class="badge bg-warning text-dark">Menunggu persetujuan</span>
                                    <?php elseif($cashRequest->status === 'approved'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($cashRequest->reviewer->officer_name ?? '-'); ?></td>
                                <td><?php echo e($cashRequest->rejection_reason ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted mb-0">Belum ada permintaan modal kas.</p>
        <?php endif; ?>
    </div>
</div>


<div class="card shadow">
    <div class="card-header bg-primary text-white">
        <strong>Transaksi Teller</strong>
    </div>

    <div class="card-body">
        <?php if($transactions->isNotEmpty()): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Waktu</th>
                            <th>Customer</th>
                            <th>Rekening</th>
                            <th>Jenis</th>
                            <th>Jumlah</th>
                            <th>Saldo Awal</th>
                            <th>Saldo Akhir</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>

                                <td>
                                    <?php echo e($transaction->date
                                        ? \Carbon\Carbon::parse($transaction->date)->timezone('Asia/Jakarta')->format('d-m-Y H:i') . ' WIB'
                                        : '-'); ?>

                                </td>

                                <td>
                                    <?php echo e($transaction->customer->name ?? '-'); ?>

                                </td>

                                <td>
                                    <?php echo e($transaction->customer->account_number ?? '-'); ?>

                                </td>

                                <td>
                                    <?php if($transaction->transaction_type === 'setoran'): ?>
                                        <span class="badge bg-success">Deposit</span>
                                    <?php elseif($transaction->transaction_type === 'penarikan'): ?>
                                        <span class="badge bg-danger">Withdrawal</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">
                                            <?php echo e($transaction->transaction_type); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    Rp <?php echo e(number_format($transaction->amount, 0, ',', '.')); ?>

                                </td>

                                <td>
                                    Rp <?php echo e(number_format($transaction->beginning_balance, 0, ',', '.')); ?>

                                </td>

                                <td>
                                    Rp <?php echo e(number_format($transaction->ending_balance, 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info mb-0">
                Belum ada transaksi pada laporan ini.
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/daily_reports/show.blade.php ENDPATH**/ ?>