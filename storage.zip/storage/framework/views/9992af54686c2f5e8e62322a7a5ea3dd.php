

<?php $__env->startSection('title','Edit Customer'); ?>

<?php $__env->startSection('content'); ?>

<h2>Edit Customer</h2>

<hr>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="card shadow">

<div class="card-body">

<form action="<?php echo e(route('customers.update',$customer->id)); ?>" method="POST">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<div class="mb-3">

<label>Account Number</label>

<input
type="text"
class="form-control"
value="<?php echo e($customer->account_number); ?>"
readonly>

</div>

<div class="mb-3">

<label>NIS</label>

<input
type="text"
name="nis"
class="form-control"
value="<?php echo e(old('nis',$customer->nis)); ?>"
required>

</div>

<div class="mb-3">

<label>Name</label>

<input
type="text"
name="name"
class="form-control"
value="<?php echo e(old('name',$customer->name)); ?>"
required>

</div>

<div class="mb-3">

<label for="email">Email</label>

<input
type="email"
id="email"
name="email"
class="form-control"
value="<?php echo e(old('email', $customer->email)); ?>"
maxlength="255"
autocomplete="email"
required>

<small class="text-muted">
Email ini digunakan untuk menerima kode OTP saat lupa password.
</small>

</div>

<div class="mb-3">

<label>Class</label>

<input
type="text"
name="class"
class="form-control"
value="<?php echo e(old('class',$customer->class)); ?>"
required>

</div>

<div class="mb-3">

<label>Location</label>

<textarea
name="location"
class="form-control"
required><?php echo e(old('location',$customer->location)); ?></textarea>

</div>

<div class="mb-3">

<label>Telephone</label>

<input
type="text"
name="telephone_number"
class="form-control"
value="<?php echo e(old('telephone_number',$customer->telephone_number)); ?>"
required>

</div>

<button class="btn btn-primary">

Update

</button>

<a href="<?php echo e(route('customers.index')); ?>"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/customers/edit.blade.php ENDPATH**/ ?>