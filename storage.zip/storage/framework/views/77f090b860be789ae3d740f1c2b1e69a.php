

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>





<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h2 class="fw-bold mb-1">
             Admin Dashboard
        </h2>

        <p class="text-muted mb-0">
            Monitoring Sistem E-Teller Bank Mini
        </p>

    </div>

    <div class="text-end">

        <small class="text-muted">
            <?php echo e(now()->format('d F Y')); ?>

        </small>

    </div>

</div>






<h5 class="fw-bold mb-3">
     User & Customer
</h5>

<div class="row g-4 mb-4">

    
    <div class="col-md-3">

        <div class="card shadow border-0 h-100">

            <div class="card-body">

                <div class="d-flex justify-content-between">

                    <div>

                        <small class="text-muted">
                            Total Users
                        </small>

                        <h2 class="fw-bold">
                            <?php echo e($totalUsers); ?>

                        </h2>

                    </div>

                    <div class="fs-1 text-primary" aria-hidden="true">
                        
                    </div>

                </div>

            </div>

        </div>

    </div>


    
    <div class="col-md-3">

        <div class="card shadow border-0 h-100">

            <div class="card-body">

                <div class="d-flex justify-content-between">

                    <div>

                        <small class="text-muted">
                            Customers
                        </small>

                        <h2 class="fw-bold text-success">
                            <?php echo e($totalCustomers); ?>

                        </h2>

                    </div>

                    <div class="fs-1 text-success" aria-hidden="true">
                        
                    </div>

                </div>

            </div>

        </div>

    </div>


    
    <div class="col-md-3">

        <div class="card shadow border-0 h-100">

            <div class="card-body">

                <div class="d-flex justify-content-between">

                    <div>

                        <small class="text-muted">
                            Tellers
                        </small>

                        <h2 class="fw-bold text-primary">
                            <?php echo e($totalTellers); ?>

                        </h2>

                    </div>

                    <div class="fs-1 text-primary" aria-hidden="true">
                        
                    </div>

                </div>

            </div>

        </div>

    </div>


    
    <div class="col-md-3">

        <div class="card shadow border-0 h-100">

            <div class="card-body">

                <div class="d-flex justify-content-between">

                    <div>

                        <small class="text-muted">
                            Supervisors
                        </small>

                        <h2 class="fw-bold text-warning">
                            <?php echo e($totalSupervisors); ?>

                        </h2>

                    </div>

                    <div class="fs-1 text-warning" aria-hidden="true">
                        
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>





<div class="card shadow border-0 mb-4">

    <div class="card-body">

        <div class="row align-items-center g-3">

            <div class="col-lg-7">

                <small class="text-muted">
                    <?php echo e($selectedBalanceClass === null
                        ? 'Total Saldo Seluruh Rekening Nasabah'
                        : 'Total Saldo Rekening Kelas '.$selectedBalanceClass); ?>

                </small>

                <div class="fs-2 fw-bold text-primary">
                    Rp <?php echo e(number_format($totalCustomerBalance, 0, ',', '.')); ?>

                </div>

                <small class="text-muted">
                    Mencakup rekening aktif dan nonaktif yang tercatat pada sistem.
                </small>

            </div>

            <div class="col-lg-5">

                <form action="<?php echo e(route('admin.dashboard')); ?>" method="GET" class="row g-2 align-items-end">

                    <div class="col-sm">

                        <label for="balance-class" class="form-label">
                            Filter berdasarkan kelas
                        </label>

                        <select id="balance-class" name="class" class="form-select">

                            <option value="">
                                Semua Kelas
                            </option>

                            <?php $__currentLoopData = $balanceClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balanceClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($balanceClass); ?>"
                                    <?php if($selectedBalanceClass === $balanceClass): echo 'selected'; endif; ?>>
                                    <?php echo e($balanceClass); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>

                    <div class="col-sm-auto d-flex gap-2">

                        <button type="submit" class="btn btn-primary">
                            
                            Terapkan
                        </button>

                        <?php if($selectedBalanceClass !== null): ?>
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-outline-secondary">
                                Reset
                            </a>
                        <?php endif; ?>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>






<h5 class="fw-bold mb-3">
     Transaksi Hari Ini
</h5>

<div class="row g-4 mb-4">

    
    <div class="col-md-3">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <h6 class="text-muted">
                    Transactions
                </h6>

                <h2 class="fw-bold text-primary">
                    <?php echo e($todayTransactions); ?>

                </h2>

            </div>

        </div>

    </div>


    
    <div class="col-md-3">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <h6 class="text-muted">
                    Total Deposit
                </h6>

                <h4 class="fw-bold text-success">

                    Rp <?php echo e(number_format(
                        $totalDeposit,
                        0,
                        ',',
                        '.'
                    )); ?>


                </h4>

            </div>

        </div>

    </div>


    
    <div class="col-md-3">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <h6 class="text-muted">
                    Total Withdrawal
                </h6>

                <h4 class="fw-bold text-danger">

                    Rp <?php echo e(number_format(
                        $totalWithdrawal,
                        0,
                        ',',
                        '.'
                    )); ?>


                </h4>

            </div>

        </div>

    </div>


    
    <div class="col-md-3">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <h6 class="text-muted">
                    All Transactions
                </h6>

                <h2 class="fw-bold">
                    <?php echo e($totalTransactions); ?>

                </h2>

            </div>

        </div>

    </div>

</div>






<h5 class="fw-bold mb-3">
     Daily Report
</h5>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div class="card shadow border-0 mb-4">
    <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
        <strong>Permintaan Modal Kas Teller</strong>
        <span class="badge bg-white text-danger"><?php echo e($pendingCashAdvanceRequests->count()); ?> menunggu</span>
    </div>
    <div class="card-body">
        <?php if($pendingCashAdvanceRequests->isEmpty()): ?>
            <p class="text-muted mb-0">Tidak ada permintaan modal kas yang menunggu.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Teller</th>
                            <th>Jumlah Diminta</th>
                            <th>Saldo Kas Saat Ini</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingCashAdvanceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cashRequest->requested_at->timezone('Asia/Jakarta')->format('d-m-Y H:i')); ?> WIB</td>
                                <td><?php echo e($cashRequest->teller->officer_name ?? '-'); ?></td>
                                <td>Rp <?php echo e(number_format($cashRequest->amount, 0, ',', '.')); ?></td>
                                <td>Rp <?php echo e(number_format($cashRequest->report->ending_balance ?? 0, 0, ',', '.')); ?></td>
                                <td style="min-width: 250px;">
                                    <form action="<?php echo e(route('cash-advance-requests.approve', $cashRequest->id)); ?>"
                                        method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success btn-sm mb-2"
                                            onclick="return confirm('Setujui permintaan modal kas ini?')">
                                            Approve
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('cash-advance-requests.reject', $cashRequest->id)); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <textarea name="rejection_reason" class="form-control form-control-sm mb-2"
                                            rows="2" minlength="5" maxlength="2000"
                                            placeholder="Alasan reject..." required><?php echo e(old('rejection_reason')); ?></textarea>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Tolak permintaan modal kas ini?')">
                                            Reject
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row g-4 mb-5">

    
    <div class="col-md-4">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <span class="badge bg-danger text-white mb-2">
                    Pending
                </span>

                <h2 class="fw-bold">
                    <?php echo e($pendingReports); ?>

                </h2>

            </div>

        </div>

    </div>


    
    <div class="col-md-4">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <span class="badge bg-success mb-2">
                    Approved
                </span>

                <h2 class="fw-bold">
                    <?php echo e($approvedReports); ?>

                </h2>

            </div>

        </div>

    </div>


    
    <div class="col-md-4">

        <div class="card shadow border-0">

            <div class="card-body text-center">

                <span class="badge bg-danger mb-2">
                    Rejected
                </span>

                <h2 class="fw-bold">
                    <?php echo e($rejectedReports); ?>

                </h2>

            </div>

        </div>

    </div>

</div>






<div class="card shadow border-0 mb-4">

    <div class="card-header bg-dark text-white">

        <strong>
             Transaksi Terbaru
        </strong>

    </div>

    <div class="card-body p-0">

        <div class="table-responsive">

            <table class="table table-bordered table-hover mb-0">

                <thead class="table-light">

                    <tr>

                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Customer</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th>Teller</th>

                    </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $latestTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>
                            <?php echo e($loop->iteration); ?>

                        </td>

                        <td>
                            <?php echo e($transaction->date); ?>

                        </td>

                        <td>

                            <?php echo e($transaction->customer->name ?? '-'); ?>


                            <br>

                            <small class="text-muted">

                                <?php echo e($transaction->customer->account_number ?? '-'); ?>


                            </small>

                        </td>

                        <td>

                            <?php if($transaction->transaction_type == 'setoran'): ?>

                                <span class="badge bg-success">
                                    Deposit
                                </span>

                            <?php else: ?>

                                <span class="badge bg-danger">
                                    Withdrawal
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            Rp <?php echo e(number_format(
                                $transaction->amount,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                        <td>

                            <?php echo e($transaction->teller->officer_name ?? '-'); ?>


                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="6"
                            class="text-center py-4"
                        >

                            Belum ada transaksi.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>






<div class="card shadow border-0 mb-4">

    <div class="card-header bg-primary text-white">

        <strong>
             Customer Terbaru
        </strong>

    </div>

    <div class="card-body p-0">

        <div class="table-responsive">

            <table class="table table-bordered table-hover mb-0">

                <thead class="table-light">

                    <tr>

                        <th>No</th>
                        <th>Account Number</th>
                        <th>NIS</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Balance</th>

                    </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $latestCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>
                            <?php echo e($loop->iteration); ?>

                        </td>

                        <td>
                            <?php echo e($customer->account_number); ?>

                        </td>

                        <td>
                            <?php echo e($customer->nis); ?>

                        </td>

                        <td>
                            <?php echo e($customer->name); ?>

                        </td>

                        <td>
                            <?php echo e($customer->class); ?>

                        </td>

                        <td>

                            Rp <?php echo e(number_format(
                                $customer->balance,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="6"
                            class="text-center py-4"
                        >

                            Belum ada customer.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>






<div class="card shadow border-0">

    <div class="card-header bg-dark text-white">

        <strong>
             Quick Action
        </strong>

    </div>

    <div class="card-body">

        <a
            href="<?php echo e(route('customers.index')); ?>"
            class="btn btn-primary me-2"
        >
             Manage Customers
        </a>

        <a
            href="<?php echo e(route('users.index')); ?>"
            class="btn btn-secondary me-2"
        >
             Manage Users
        </a>

        <a
            href="<?php echo e(route('daily-reports.index')); ?>"
            class="btn btn-warning me-2"
        >
             Daily Reports
        </a>

        <a
            href="<?php echo e(route('accounting-journal.index')); ?>"
            class="btn btn-success"
        >
             Accounting Journal
        </a>

        <a href="<?php echo e(route('monthly-reports.index')); ?>" class="btn btn-primary">
    Laporan Bulanan
</a>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>