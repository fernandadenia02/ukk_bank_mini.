

<?php $__env->startSection('title','Accounting Journal'); ?>

<?php $__env->startSection('content'); ?>

<h2>Accounting Journal</h2>

<hr>

<form method="GET" action="<?php echo e(route('accounting-journal.index')); ?>" class="row g-2 align-items-end mb-3">
    <div class="col-md-4">
        <label for="keyword" class="form-label">Cari akun</label>
        <input
            type="text"
            id="keyword"
            name="keyword"
            value="<?php echo e($keyword); ?>"
            class="form-control"
            placeholder="Search account..."
        >
    </div>
    <div class="col-md-3">
        <label for="date_from" class="form-label">Dari tanggal</label>
        <input
            type="date"
            id="date_from"
            name="date_from"
            value="<?php echo e($dateFrom); ?>"
            class="form-control"
        >
    </div>
    <div class="col-md-3">
        <label for="date_to" class="form-label">Sampai tanggal</label>
        <input
            type="date"
            id="date_to"
            name="date_to"
            value="<?php echo e($dateTo); ?>"
            class="form-control"
        >
    </div>
    <div class="col-md-2 d-flex gap-2">
        <button type="submit" class="btn btn-primary">Filter</button>
        <a href="<?php echo e(route('accounting-journal.index')); ?>" class="btn btn-outline-secondary">Reset</a>
    </div>
</form>

<table class="table table-bordered table-striped">

    <thead class="table-dark">

        <tr>

            <th>No</th>

            <th>Date</th>

            <th>Transaction</th>

            <th>Customer</th>

            <th>Account</th>

            <th>Debit</th>

            <th>Credit</th>

        </tr>

    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <tr>

        <td><?php echo e($loop->iteration); ?></td>

        <td><?php echo e(\Illuminate\Support\Carbon::parse($journal->date)->timezone('Asia/Jakarta')->format('Y-m-d H:i:s')); ?> WIB</td>

        <td>#<?php echo e($journal->transaction_id); ?></td>

        <td><?php echo e($journal->transaction->customer->name ?? '-'); ?></td>

        <td><?php echo e($journal->account); ?></td>

        <td>
            Rp <?php echo e(number_format($journal->debit,0,',','.')); ?>

        </td>

        <td>
            Rp <?php echo e(number_format($journal->credit,0,',','.')); ?>

        </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <tr>

        <td colspan="7" class="text-center">

            No Journal Found

        </td>

    </tr>

    <?php endif; ?>

    </tbody>

</table>

<div class="mt-3">

    <h5>Total Debit :
        Rp <?php echo e(number_format($totalDebit,0,',','.')); ?>

    </h5>

    <h5>Total Credit :
        Rp <?php echo e(number_format($totalCredit,0,',','.')); ?>

    </h5>

</div>

<?php echo e($journals->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/accounting_journal/index.blade.php ENDPATH**/ ?>