<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title><?php echo $__env->yieldContent('title'); ?> | E-Teller Bank Mini</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        /* =====================================
           GLOBAL
        ===================================== */

        body {
            background: #f4f6f9;
            overflow-x: hidden;
            margin: 0;
        }


        /* =====================================
           SIDEBAR
        ===================================== */

        .sidebar {

            width: 250px;

            height: 100vh;

            position: fixed;

            left: 0;
            top: 0;

            background: #0d6efd;

            color: white;

            overflow-y: auto;

            z-index: 1050;

            transition: transform .3s ease;

        }


        .sidebar h4 {

            padding: 20px;

            margin: 0;

            text-align: center;

            border-bottom:
                1px solid
                rgba(255,255,255,.2);

        }


        .sidebar a {

            color: white;

            text-decoration: none;

            display: block;

            padding: 14px 20px;

            transition: .2s;

        }


        .sidebar a:hover {

            background:
                rgba(255,255,255,.15);

        }


        .sidebar a.active {

            background: white;

            color: #0d6efd;

            font-weight: bold;

        }


        /* =====================================
           SIDEBAR CLOSE BUTTON
        ===================================== */

        .sidebar-close {

            display: none;

            position: absolute;

            top: 15px;

            right: 15px;

            border: none;

            background: transparent;

            color: white;

            font-size: 24px;

        }


        /* =====================================
           CONTENT
        ===================================== */

        .content {

            margin-left: 250px;

            min-height: 100vh;

            transition:
                margin-left .3s ease;

        }


        /* =====================================
           TOPBAR
        ===================================== */

        .topbar {

            background: white;

            min-height: 70px;

            box-shadow:
                0 2px 8px
                rgba(0,0,0,.08);

            display: flex;

            align-items: center;

        }


        .main-content {

            padding: 25px;

        }


        /* =====================================
           MENU BUTTON
        ===================================== */

        .menu-button {

            display: none;

            border: none;

            background: transparent;

            font-size: 25px;

            margin-right: 15px;

            color: #212529;

        }


        /* =====================================
           OVERLAY
        ===================================== */

        .sidebar-overlay {

            display: none;

            position: fixed;

            inset: 0;

            background:
                rgba(0,0,0,.45);

            z-index: 1040;

        }


        /* =====================================
           CARD
        ===================================== */

        .card {

            border: none;

            border-radius: 12px;

        }


        /* =====================================
           TABLE
        ===================================== */

        .table-responsive {

            overflow-x: auto;

        }


        /* =====================================
           MOBILE
        ===================================== */

        @media (max-width: 767.98px) {


            /* SIDEBAR TERTUTUP */

            .sidebar {

                transform:
                    translateX(-100%);

            }


            /* SIDEBAR TERBUKA */

            .sidebar.show {

                transform:
                    translateX(0);

            }


            /* CONTENT FULL WIDTH */

            .content {

                margin-left: 0;

                width: 100%;

            }


            /* MENU BUTTON */

            .menu-button {

                display: inline-block;

            }


            /* CLOSE BUTTON */

            .sidebar-close {

                display: block;

            }


            /* OVERLAY */

            .sidebar-overlay.show {

                display: block;

            }


            /* TOPBAR */

            .topbar {

                padding-left: 15px !important;

                padding-right: 15px !important;

                min-height: 65px;

            }


            .topbar-title {

                font-size: 1rem;

                white-space: nowrap;

                overflow: hidden;

                text-overflow: ellipsis;

            }


            /* USER AREA */

            .user-area {

                gap: 8px;

            }


            .user-info {

                display: none;

            }


            /* LOGOUT */

            .logout-button {

                padding: 8px 10px;

            }


            .logout-button span {

                display: none;

            }


            /* CONTENT */

            .main-content {

                padding: 15px;

            }


            /* H2 */

            .main-content h2 {

                font-size: 1.5rem;

            }

        }


        /* =====================================
           VERY SMALL PHONE
        ===================================== */

        @media (max-width: 400px) {

            .main-content {

                padding: 12px;

            }


            .topbar-title {

                max-width: 130px;

            }


            .menu-button {

                font-size: 22px;

                margin-right: 8px;

            }

        }

    </style>

    <link
        href="<?php echo e(asset('css/bank-mini-ui.css')); ?>"
        rel="stylesheet"
    >

</head>


<body>






<div
    class="sidebar"
    id="sidebar"
>


    

    <h4>

        Bank Mini

    </h4>


    

    <button
        type="button"
        class="sidebar-close"
        id="sidebarClose"
        aria-label="Tutup navigasi"
        aria-controls="sidebar"
    >

        

    </button>


    
    
    

    <?php if(session('role') == 'admin'): ?>


        <a
            href="<?php echo e(route('admin.dashboard')); ?>"
            class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
        >

            Dashboard

        </a>


        <a
            href="<?php echo e(route('users.index')); ?>"
            class="<?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>"
        >

            Users

        </a>


        <a
            href="<?php echo e(route('customers.index')); ?>"
            class="<?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>"
        >

            Customers

        </a>


        <a
            href="<?php echo e(route('members.index')); ?>"
            class="<?php echo e(request()->routeIs('members.promotion', 'members.promote') ? '' : (request()->routeIs('members.*') ? 'active' : '')); ?>"
        >

            Anggota

        </a>

        <a
            href="<?php echo e(route('members.promotion')); ?>"
            class="<?php echo e(request()->routeIs('members.promotion', 'members.promote') ? 'active' : ''); ?>"
        >

            Naik Kelas

        </a>


        <a
            href="<?php echo e(route('daily-reports.index')); ?>"
            class="<?php echo e(request()->routeIs('daily-reports.*') ? 'active' : ''); ?>"
        >

            Daily Reports

        </a>

        <a
            href="<?php echo e(route('monthly-reports.index')); ?>"
            class="<?php echo e(request()->routeIs('monthly-reports.*') ? 'active' : ''); ?>"
        >

            Laporan Bulanan

        </a>


        <a
            href="<?php echo e(route('accounting-journal.index')); ?>"
            class="<?php echo e(request()->routeIs('accounting-journal.*') ? 'active' : ''); ?>"
        >

            Accounting Journal

        </a>


    
    
    

    <?php elseif(session('role') == 'teller'): ?>


        <a
            href="<?php echo e(route('teller.dashboard')); ?>"
            class="<?php echo e(request()->routeIs('teller.dashboard') ? 'active' : ''); ?>"
        >

            Dashboard

        </a>


        <a
            href="<?php echo e(route('transactions.index')); ?>"
            class="<?php echo e(request()->routeIs('transactions.*') ? 'active' : ''); ?>"
        >

            Transactions

        </a>

        <a
            href="<?php echo e(route('teller.members.index')); ?>"
            class="<?php echo e(request()->routeIs('teller.members.*') ? 'active' : ''); ?>"
        >

            Buka Rekening

        </a>

    
    
    

    <?php elseif(session('role') == 'supervisor'): ?>


        <a
            href="<?php echo e(route('supervisor.dashboard')); ?>"
            class="<?php echo e(request()->routeIs('supervisor.dashboard') ? 'active' : ''); ?>"
        >

            Dashboard

        </a>


        <a
            href="<?php echo e(route('daily-reports.index')); ?>"
            class="<?php echo e(request()->routeIs('daily-reports.*') ? 'active' : ''); ?>"
        >

            Daily Reports

        </a>


    
    
    

    <?php elseif(session('role') == 'customer'): ?>


        <a
            href="<?php echo e(route('customer.dashboard')); ?>"
            class="<?php echo e(request()->routeIs('customer.dashboard') ? 'active' : ''); ?>"
        >

            Dashboard

        </a>


    <?php endif; ?>


</div>







<div
    class="sidebar-overlay"
    id="sidebarOverlay"
    aria-hidden="true"
></div>







<div class="content">


    
    
    

    <nav class="navbar topbar px-4">


        <div class="d-flex align-items-center">


            

            <button
                type="button"
                class="menu-button"
                id="sidebarToggle"
                aria-label="Buka navigasi"
                aria-controls="sidebar"
                aria-expanded="false"
            >

                ☰

            </button>


            

            <h5 class="mb-0 topbar-title">

                <?php echo $__env->yieldContent('title'); ?>

            </h5>


        </div>



        
        
        

        <div
            class="d-flex align-items-center user-area ms-auto"
        >


            

            <div class="user-info text-end me-3">

                <div>

                    <?php echo e(session('officer_name')); ?>


                </div>


                <span class="badge bg-primary">

                    <?php echo e(ucfirst(session('role'))); ?>


                </span>

            </div>


            

            <form
                action="<?php echo e(route('logout')); ?>"
                method="POST"
            >

                <?php echo csrf_field(); ?>

                <button
                    type="submit"
                    class="btn btn-danger logout-button"
                >

                    <span>
                        Logout
                    </span>

                </button>

            </form>


        </div>


    </nav>



    
    
    

    <div class="main-content">


        <?php if(session('success')): ?>

            <div class="alert alert-success">

                <?php echo e(session('success')); ?>


            </div>

        <?php endif; ?>


        <?php if(session('error')): ?>

            <div class="alert alert-danger">

                <?php echo e(session('error')); ?>


            </div>

        <?php endif; ?>


        <?php echo $__env->yieldContent('content'); ?>


    </div>


</div>







<script>

document.addEventListener('DOMContentLoaded', function () {


    const sidebar =
        document.getElementById('sidebar');


    const toggle =
        document.getElementById('sidebarToggle');


    const close =
        document.getElementById('sidebarClose');


    const overlay =
        document.getElementById('sidebarOverlay');


    /* =====================================
       OPEN SIDEBAR
    ===================================== */

    if (!sidebar || !toggle || !close || !overlay) {
        return;
    }

    toggle.addEventListener('click', function () {
        sidebar.classList.add('show');
        overlay.classList.add('show');
        toggle.setAttribute('aria-expanded', 'true');
    });


    /* =====================================
       CLOSE SIDEBAR
    ===================================== */

    function closeSidebar() {

        sidebar.classList.remove('show');
        overlay.classList.remove('show');
        toggle.setAttribute('aria-expanded', 'false');
    }


    close.addEventListener(
        'click',
        closeSidebar
    );


    overlay.addEventListener(
        'click',
        closeSidebar
    );


    /* =====================================
       CLOSE AFTER CLICK MENU
       KHUSUS MOBILE
    ===================================== */

    sidebar
        .querySelectorAll('a')
        .forEach(function (link) {

            link.addEventListener(
                'click',
                function () {

                    if (
                        window.innerWidth <= 767
                    ) {

                        closeSidebar();

                    }

                }
            );

        });


});

</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/layouts/app.blade.php ENDPATH**/ ?>