

<?php $__env->startSection('title', 'Lupa Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5" style="max-width: 450px;">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h4>Lupa Password</h4>
            <p class="mb-0">Pemulihan akun Bank Mini</p>
        </div>

        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <p>
                Masukkan ID database admin/teller atau nomor rekening customer,
                beserta email yang terdaftar pada akun.
            </p>

            <form action="<?php echo e(route('password.otp.send')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="identity" class="form-label">
                        ID Admin/Teller atau Nomor Rekening Customer
                    </label>

                    <input
                        type="text"
                        id="identity"
                        name="identity"
                        class="form-control"
                        value="<?php echo e(old('identity')); ?>"
                        autocomplete="username"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">
                        Alamat Email
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        class="form-control"
                        value="<?php echo e(old('email')); ?>"
                        maxlength="255"
                        autocomplete="email"
                        required
                    >
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    Kirim Kode OTP
                </button>
            </form>

            <div class="text-center mt-3">
                <a href="<?php echo e(route('login')); ?>">Kembali ke Login</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>