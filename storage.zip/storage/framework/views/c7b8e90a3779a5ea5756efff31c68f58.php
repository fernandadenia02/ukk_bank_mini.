

<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5" style="max-width: 450px;">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h4>Reset Password</h4>
        </div>

        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <p>
                Masukkan kembali ID admin/teller atau nomor rekening customer,
                email terdaftar, kode OTP 6 digit dari email, dan password baru minimal 4 karakter.
            </p>

            <form action="<?php echo e(route('password.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="identity" class="form-label">
                        ID Admin/Teller atau Nomor Rekening Customer
                    </label>

                    <input
                        type="text"
                        id="identity"
                        name="identity"
                        class="form-control"
                        value="<?php echo e(old('identity')); ?>"
                        autocomplete="username"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">
                        Alamat Email
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        class="form-control"
                        value="<?php echo e(old('email')); ?>"
                        maxlength="255"
                        autocomplete="email"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label for="otp" class="form-label">Kode OTP</label>

                    <input
                        type="text"
                        id="otp"
                        name="otp"
                        class="form-control"
                        inputmode="numeric"
                        pattern="[0-9]{6}"
                        minlength="6"
                        maxlength="6"
                        autocomplete="one-time-code"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">
                        Password Baru
                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="form-control"
                        minlength="4"
                        autocomplete="new-password"
                        required
                    >
                    <small class="text-muted">Minimal 4 karakter.</small>
                </div>

                <div class="mb-3">
                    <label for="password_confirmation" class="form-label">
                        Konfirmasi Password Baru
                    </label>

                    <input
                        type="password"
                        id="password_confirmation"
                        name="password_confirmation"
                        class="form-control"
                        minlength="4"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <button type="submit" class="btn btn-success w-100">
                    Ubah Password
                </button>
            </form>

            <div class="text-center mt-3">
                <a href="<?php echo e(route('password.request')); ?>">
                    Minta OTP baru
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>