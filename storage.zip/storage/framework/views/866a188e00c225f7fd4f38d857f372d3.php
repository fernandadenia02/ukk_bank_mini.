

<?php $__env->startSection('title', 'Add Anggota'); ?>

<?php $__env->startSection('content'); ?>
<h2>Tambah Anggota</h2>
<p class="text-muted">Masukkan data calon nasabah. Informasi kontak dan rekening diisi saat pembuatan rekening.</p>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="<?php echo e(route('members.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nis" class="form-label">NIS</label>
                <input type="text" id="nis" name="nis" class="form-control"
                    value="<?php echo e(old('nis')); ?>" maxlength="30" required>
            </div>

            <div class="mb-3">
                <label for="name" class="form-label">Nama</label>
                <input type="text" id="name" name="name" class="form-control"
                    value="<?php echo e(old('name')); ?>" maxlength="100" required>
            </div>

            <div class="mb-3">
                <label for="class" class="form-label">Kelas</label>
                <input type="text" id="class" name="class" class="form-control"
                    value="<?php echo e(old('class')); ?>" maxlength="20" required>
            </div>

            <div class="mb-3">
                <label for="location" class="form-label">Lokasi</label>
                <textarea id="location" name="location" class="form-control" rows="3" required><?php echo e(old('location')); ?></textarea>
            </div>

            <button type="submit" class="btn btn-success">Simpan Anggota</button>
            <a href="<?php echo e(route('members.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/members/create.blade.php ENDPATH**/ ?>