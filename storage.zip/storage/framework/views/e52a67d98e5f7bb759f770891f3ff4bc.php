

<?php $__env->startSection('title', 'Buat Rekening'); ?>

<?php $__env->startSection('content'); ?>
<h2>Buka Rekening dari Anggota</h2>
<p class="text-muted">Lengkapi data rekening dan setoran awal calon nasabah.</p>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-3"><strong>NIS</strong><div><?php echo e($member->nis); ?></div></div>
            <div class="col-md-3"><strong>Nama</strong><div><?php echo e($member->name); ?></div></div>
            <div class="col-md-3"><strong>Kelas</strong><div><?php echo e($member->class); ?></div></div>
            <div class="col-md-3"><strong>Lokasi</strong><div><?php echo e($member->location); ?></div></div>
        </div>

        <form action="<?php echo e(route('teller.members.open', $member->id)); ?>" method="POST"
            onsubmit="return confirm('Buka rekening dan catat setoran awal Rp ' + document.getElementById('opening_deposit').value + '?')">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" name="email" class="form-control"
                    value="<?php echo e(old('email')); ?>" maxlength="255" autocomplete="email" required>
            </div>

            <div class="mb-3">
                <label for="telephone_number" class="form-label">Nomor Telepon</label>
                <input type="text" id="telephone_number" name="telephone_number" class="form-control"
                    value="<?php echo e(old('telephone_number')); ?>" maxlength="20" inputmode="tel" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password Login</label>
                <input type="password" id="password" name="password" class="form-control"
                    minlength="4" autocomplete="new-password" required>
                <small class="text-muted">Minimal 4 karakter.</small>
            </div>

            <div class="mb-3">
                <label for="pin" class="form-label">PIN Transaksi</label>
                <input type="password" id="pin" name="pin" class="form-control"
                    inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6"
                    autocomplete="new-password" required>
                <small class="text-muted">PIN harus terdiri dari 6 angka.</small>
            </div>

            <div class="mb-3">
                <label for="opening_deposit" class="form-label">Setoran Awal</label>
                <div class="input-group">
                    <span class="input-group-text">Rp</span>
                    <input type="text" id="opening_deposit" name="opening_deposit" class="form-control"
                        value="<?php echo e(old('opening_deposit', '10.000')); ?>" inputmode="numeric"
                        pattern="[0-9.]*" autocomplete="off" required>
                </div>
                <small class="text-muted">Setoran awal minimal Rp 10.000 dan akan tercatat sebagai transaksi setoran.</small>
            </div>

            <div class="alert alert-info">
                Setelah setoran berhasil dicatat, rekening langsung aktif dengan saldo sebesar setoran awal.
                Data anggota tetap tersimpan di daftar Anggota untuk pemeriksaan.
            </div>

            <button type="submit" class="btn btn-success">Buka Rekening dan Simpan Setoran</button>
            <a href="<?php echo e(route('teller.members.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const openingDeposit = document.getElementById('opening_deposit');

        function formatAmount(value) {
            const digits = value.replace(/\D/g, '');
            return digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }

        openingDeposit.value = formatAmount(openingDeposit.value);
        openingDeposit.addEventListener('input', function () {
            const cursor = openingDeposit.selectionStart;
            const digitsBeforeCursor = openingDeposit.value
                .slice(0, cursor)
                .replace(/\D/g, '')
                .length;
            const formatted = formatAmount(openingDeposit.value);
            openingDeposit.value = formatted;

            let nextCursor = 0;
            let digitsCount = 0;
            while (nextCursor < formatted.length && digitsCount < digitsBeforeCursor) {
                if (/\d/.test(formatted[nextCursor])) {
                    digitsCount++;
                }
                nextCursor++;
            }
            openingDeposit.setSelectionRange(nextCursor, nextCursor);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/members/activate.blade.php ENDPATH**/ ?>