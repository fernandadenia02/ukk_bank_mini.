

<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('content'); ?>

<h2>Transaction Data</h2>

<hr>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<a href="<?php echo e(route('transactions.create')); ?>"
   class="btn btn-primary mb-3">

    New Transaction

</a>

<table class="table table-bordered table-hover">
<thead class="table-dark">

    <tr>

        <th>No</th>
        <th>Date</th>
        <th>Customer</th>
        <th>Account Number</th>
        <th>Type</th>
        <th>Amount</th>
        <th>Beginning Balance</th>
        <th>Ending Balance</th>
        <th>Teller</th>
        <th>Action</th>

    </tr>

</thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

            <td><?php echo e(($transactions->currentPage()-1) * $transactions->perPage() + $loop->iteration); ?></td>

            <td><?php echo e($transaction->date); ?></td>

            <td><?php echo e($transaction->customer->name ?? '-'); ?></td>

            <td><?php echo e($transaction->customer->account_number ?? '-'); ?></td>

            <td>

                <?php if($transaction->transaction_type == 'setoran'): ?>

                    <span class="badge bg-success">
                        Deposit
                    </span>

                <?php else: ?>

                    <span class="badge bg-danger">
                        Withdrawal
                    </span>

                <?php endif; ?>

            </td>

            <td>

                Rp <?php echo e(number_format($transaction->amount,0,',','.')); ?>


            </td>

            <td>

                Rp <?php echo e(number_format($transaction->beginning_balance,0,',','.')); ?>


            </td>

            <td>

                Rp <?php echo e(number_format($transaction->ending_balance,0,',','.')); ?>


            </td>

            <td>

                <?php echo e($transaction->teller->officer_name ?? '-'); ?>


            </td>

            <td>

    <a
        href="<?php echo e(route('transactions.receipt', $transaction->id)); ?>"
        target="_blank"
        class="btn btn-primary btn-sm"
    >
         Cetak
    </a>

</td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>

            <td colspan="10" class="text-center">

                No transaction data.

            </td>

        </tr>

    <?php endif; ?>

    </tbody>

</table>

<?php echo e($transactions->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/transactions/index.blade.php ENDPATH**/ ?>