

<?php $__env->startSection('title', 'Anggota'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
        <h2 class="mb-1">Data Anggota</h2>
        <p class="text-muted mb-0">
            <?php echo e($forTeller ? 'Pilih calon nasabah untuk membuka rekening dengan setoran awal minimal Rp 10.000.' : 'Daftar calon nasabah dan riwayat pembukaan rekening.'); ?>

        </p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <span class="badge bg-primary fs-6"><?php echo e($members->total()); ?> anggota</span>
        <?php if (! ($forTeller)): ?>
            <a href="<?php echo e(route('members.create')); ?>" class="btn btn-primary">
                
                Add Anggota
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if(session('import_errors')): ?>
    <div class="alert alert-danger">
        <strong>Import dibatalkan. Tidak ada anggota yang disimpan:</strong>
        <ul class="mb-0 mt-2">
            <?php $__currentLoopData = session('import_errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $importError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($importError); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if (! ($forTeller)): ?>
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <h5>Import Calon Nasabah dari Excel</h5>
        <p class="text-muted">
            File anggota hanya memuat NIS, nama, kelas, dan lokasi. Email, nomor telepon,
            password login, serta PIN dimasukkan teller saat membuka rekening.
        </p>
        <div class="d-flex flex-wrap gap-2 align-items-start">
            <a href="<?php echo e(route('members.import.template')); ?>" class="btn btn-outline-primary">
                
                Unduh Template Anggota
            </a>
            <form action="<?php echo e(route('members.import')); ?>" method="POST" enctype="multipart/form-data"
                class="d-flex flex-wrap gap-2">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" class="form-control" accept=".xlsx" required>
                <button type="submit" class="btn btn-success">
                    
                    Upload Anggota
                </button>
            </form>
        </div>
        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger mt-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php endif; ?>

<form action="<?php echo e($forTeller ? route('teller.members.index') : route('members.index')); ?>"
    method="GET" class="d-flex gap-2 mb-3">
    <input type="search" name="keyword" class="form-control" placeholder="Cari NIS, nama, atau kelas..."
        value="<?php echo e($keyword); ?>">
    <button class="btn btn-primary">Cari</button>
    <a href="<?php echo e(route('members.index')); ?>" class="btn btn-secondary">Reset</a>
</form>

<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Lokasi</th>
                <?php if($forTeller): ?>
                    <th>Aksi</th>
                <?php else: ?>
                    <th>Nomor Rekening</th>
                    <th>Status Rekening</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(($members->currentPage() - 1) * $members->perPage() + $loop->iteration); ?></td>
                    <td><?php echo e($member->nis); ?></td>
                    <td><?php echo e($member->name); ?></td>
                    <td><?php echo e($member->class); ?></td>
                    <td><?php echo e($member->location); ?></td>
                    <?php if($forTeller): ?>
                        <td>
                            <a href="<?php echo e(route('teller.members.open.form', $member->id)); ?>" class="btn btn-success btn-sm">
                                
                                Buka Rekening
                            </a>
                        </td>
                    <?php else: ?>
                        <td><?php echo e($member->customer->account_number ?? '-'); ?></td>
                        <td>
                            <?php if($member->customer): ?>
                                <?php if($member->customer->status === 'aktif'): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Nonaktif</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge bg-danger text-white">Belum dibuka</span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($forTeller ? 6 : 7); ?>" class="text-center py-4">
                        <?php echo e($forTeller ? 'Tidak ada calon nasabah yang menunggu pembukaan rekening.' : 'Belum ada data anggota.'); ?>

                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="d-flex justify-content-center">
    <?php echo e($members->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/members/index.blade.php ENDPATH**/ ?>