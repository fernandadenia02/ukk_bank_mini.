

<?php $__env->startSection('title', 'Teller Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    
    

    <div class="mb-4">

        <h2 class="fw-bold">
            Teller Dashboard
        </h2>

        <p class="text-muted mb-0">
            Selamat datang di sistem E-Teller Bank Mini.
        </p>

    </div>


    
    
    

    <div class="row g-4 mb-4">

        
        <div class="col-md-4">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Today's Transactions
                            </p>

                            <h2 class="fw-bold mb-0">
                                <?php echo e($todayTransactions); ?>

                            </h2>

                        </div>

                        <div
                            class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:50px;height:50px;"
                        >

                            

                        </div>

                    </div>

                </div>

            </div>

        </div>


        
        <div class="col-md-4">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Total Deposit
                            </p>

                            <h2 class="fw-bold text-success mb-0">

                                Rp <?php echo e(number_format(
                                    $totalDeposit,
                                    0,
                                    ',',
                                    '.'
                                )); ?>


                            </h2>

                        </div>

                        <div
                            class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:50px;height:50px;"
                        >

                            

                        </div>

                    </div>

                </div>

            </div>

        </div>


        
        <div class="col-md-4">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Total Withdrawal
                            </p>

                            <h2 class="fw-bold text-danger mb-0">

                                Rp <?php echo e(number_format(
                                    $totalWithdrawal,
                                    0,
                                    ',',
                                    '.'
                                )); ?>


                            </h2>

                        </div>

                        <div
                            class="bg-danger text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:50px;height:50px;"
                        >

                            

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    
    
    

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">

                

                Search Nasabah

            </h5>

        </div>


        <div class="card-body">

            <form
                action="<?php echo e(route('teller.dashboard')); ?>"
                method="GET"
            >

                <div class="row g-2">

                    <div class="col-md-8">

                        <input
                            type="text"
                            name="search"
                            class="form-control form-control-lg"
                            placeholder="Cari nama atau nomor rekening nasabah..."
                            value="<?php echo e($search ?? ''); ?>"
                        >

                    </div>


                    <div class="col-md-2">

                        <button
                            type="submit"
                            class="btn btn-primary btn-lg w-100"
                        >

                            

                            Cari

                        </button>

                    </div>

                    <div class="col-md-2">

                        <a
                            href="<?php echo e(route('transactions.create', ['scan' => 1])); ?>#qr-scanner"
                            class="btn btn-success btn-lg w-100"
                        >

                            

                            Scan QR

                        </a>

                    </div>

                </div>

            </form>


            
            
            

            <?php if(!empty($search)): ?>

                <hr>

                <h6 class="fw-bold mb-3">

                    Hasil pencarian untuk:
                    <span class="text-primary">
                        "<?php echo e($search); ?>"
                    </span>

                </h6>


                <?php if($customers->count() > 0): ?>

                    <div class="table-responsive">

                        <table class="table table-hover align-middle">

                            <thead class="table-light">

                                <tr>

                                    <th>No</th>

                                    <th>Nomor Rekening</th>

                                    <th>Nama Nasabah</th>

                                    <th>Saldo</th>

                                    <th>Status</th>

                                    <th width="180">
                                        Aksi
                                    </th>

                                </tr>

                            </thead>


                            <tbody>

                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>

                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>


                                        <td>

                                            <span class="fw-bold">

                                                <?php echo e($customer->account_number); ?>


                                            </span>

                                        </td>


                                        <td>

                                            <?php echo e($customer->name); ?>


                                        </td>


                                        <td>

                                            <span class="text-success fw-bold">

                                                Rp
                                                <?php echo e(number_format(
                                                    $customer->balance,
                                                    0,
                                                    ',',
                                                    '.'
                                                )); ?>


                                            </span>

                                        </td>

                                        <td>
                                            <?php if($customer->status === 'aktif'): ?>
                                                <span class="badge bg-success">Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Belum aktif</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>

                                            <a
                                                href="<?php echo e(route(
                                                    'transactions.create',
                                                    ['customer_id' => $customer->id]
                                                )); ?>"
                                                class="btn btn-success btn-sm"
                                            >

                                                

                                                <?php echo e($customer->status === 'aktif' ? 'Transaksi' : 'Aktivasi'); ?>


                                            </a>

                                        </td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </div>

                <?php else: ?>

                    <div class="alert alert-warning mb-0">

                        

                        Nasabah dengan nama atau nomor rekening

                        <strong>
                            "<?php echo e($search); ?>"
                        </strong>

                        tidak ditemukan.

                    </div>

                <?php endif; ?>

            <?php endif; ?>

        </div>

    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-warning">
            <h5 class="mb-0">
                
                Customer Belum Aktif
                <span class="badge bg-dark"><?php echo e($inactiveCustomers->total()); ?></span>
            </h5>
        </div>
        <div class="card-body">
            <p class="text-muted">
                Untuk mengaktifkan rekening, buka rekening dari daftar Anggota dan masukkan setoran awal minimal Rp 10.000.
                Setoran pembukaan akan dicatat sebagai transaksi.
            </p>
            <a href="<?php echo e(route('teller.members.index')); ?>" class="btn btn-primary mb-3">
                
                Buka Rekening dari Data Anggota
            </a>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nomor Rekening</th>
                            <th>Nama Nasabah</th>
                            <th>Saldo</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $inactiveCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(($inactiveCustomers->currentPage() - 1) * $inactiveCustomers->perPage() + $loop->iteration); ?></td>
                            <td><?php echo e($customer->account_number); ?></td>
                            <td><?php echo e($customer->name); ?></td>
                            <td>Rp <?php echo e(number_format($customer->balance, 0, ',', '.')); ?></td>
                            <td>
                                <a
                                    href="<?php echo e(route('transactions.create', ['customer_id' => $customer->id, 'activation' => 1])); ?>"
                                    class="btn btn-success btn-sm"
                                >
                                    
                                    Aktivasi via Setoran
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">Tidak ada customer yang menunggu aktivasi.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center">
                <?php echo e($inactiveCustomers->links()); ?>

            </div>
        </div>
    </div>


    
    
    

    <?php if($rejectedReports->isNotEmpty()): ?>
        <div class="card shadow-sm border-danger mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">
                    
                    Catatan Penolakan Laporan
                </h5>
            </div>

            <div class="list-group list-group-flush">
                <?php $__currentLoopData = $rejectedReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rejectedReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-start gap-3">
                            <div>
                                <strong><?php echo e($rejectedReport->date); ?></strong>
                                <div class="mt-1" style="white-space: pre-line;"><?php echo e($rejectedReport->rejection_reason ?: 'Alasan penolakan belum tersedia.'); ?></div>
                            </div>
                            <a
                                href="<?php echo e(route('teller.daily-reports.show', $rejectedReport->id)); ?>"
                                class="btn btn-outline-danger btn-sm flex-shrink-0"
                            >
                                Detail
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if($dailyReport): ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm">

            <div class="card-header">

                <h5 class="mb-0">

                    

                    Daily Report Hari Ini

                </h5>

            </div>


            <div class="card-body">

                <div class="row">

                    <div class="col-md">
                        <small class="text-muted">Modal Awal Kas</small>
                        <h5 class="text-primary">
                            Rp <?php echo e(number_format($dailyReport->beginning_balance, 0, ',', '.')); ?>

                        </h5>
                    </div>

                    <div class="col-md">

                        <small class="text-muted">
                            Total Setoran
                        </small>

                        <h5 class="text-success">

                            Rp
                            <?php echo e(number_format(
                                $dailyReport->total_deposit,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </h5>

                    </div>


                    <div class="col-md">

                        <small class="text-muted">
                            Total Penarikan
                        </small>

                        <h5 class="text-danger">

                            Rp
                            <?php echo e(number_format(
                                $dailyReport->total_withdrawals,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </h5>

                    </div>


                    <div class="col-md">

                        <small class="text-muted">
                            Sisa Modal Awal / Kas Tersedia
                        </small>

                        <h5>

                            Rp
                            <?php echo e(number_format(
                                $dailyReport->ending_balance,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </h5>

                    </div>


                    <div class="col-md">

                        <small class="text-muted">
                            Status
                        </small>

                        <h5>

                            <?php if($dailyReport->status == 'pending'): ?>

                                <span class="badge bg-warning">
                                    Pending
                                </span>

                            <?php elseif($dailyReport->status == 'approved'): ?>

                                <span class="badge bg-success">
                                    Approved
                                </span>

                            <?php else: ?>

                                <span class="badge bg-danger">
                                    Rejected
                                </span>

                            <?php endif; ?>

                        </h5>

                    </div>

                </div>

                <hr>
                <?php if(!$dailyReport->closed_at && $dailyReport->status === 'pending'): ?>
                    <?php if($dailyReport->ending_balance <= 0 && !$cashAdvanceRequests->contains('status', 'pending')): ?>
                        <form action="<?php echo e(route('teller.daily-reports.opening-cash')); ?>" method="POST"
                            class="row g-2 align-items-end mb-3">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-5">
                                <label for="opening_cash" class="form-label mb-1">Ajukan modal kas ke admin</label>
                                <div class="input-group">
                                    <span class="input-group-text">Rp</span>
                                    <input type="text" id="opening_cash" name="amount"
                                        class="form-control" inputmode="numeric" pattern="[0-9.]*"
                                        value="<?php echo e(old('amount')); ?>"
                                        required>
                                </div>
                                <div class="form-text">Permintaan akan menambah saldo kas setelah disetujui admin.</div>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary">Kirim Permintaan Modal</button>
                            </div>
                        </form>
                    <?php elseif($cashAdvanceRequests->contains('status', 'pending')): ?>
                        <div class="alert alert-warning">
                            Permintaan modal sedang menunggu persetujuan admin. Transaksi penarikan dapat dilakukan setelah disetujui dan kas tersedia.
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if($cashAdvanceRequests->isNotEmpty()): ?>
                    <div class="mb-3">
                        <strong>Riwayat Permintaan Modal Kas</strong>
                        <div class="table-responsive mt-2">
                            <table class="table table-sm table-bordered align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Waktu</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                        <th>Catatan Admin</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cashAdvanceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($cashRequest->requested_at->timezone('Asia/Jakarta')->format('d-m-Y H:i')); ?> WIB</td>
                                            <td>Rp <?php echo e(number_format($cashRequest->amount, 0, ',', '.')); ?></td>
                                            <td>
                                                <?php if($cashRequest->status === 'pending'): ?>
                                                    <span class="badge bg-warning text-dark">Menunggu persetujuan</span>
                                                <?php elseif($cashRequest->status === 'approved'): ?>
                                                    <span class="badge bg-success">Disetujui</span>
                                                    <?php if($cashRequest->reviewer): ?>
                                                        <div class="small text-muted"><?php echo e($cashRequest->reviewer->officer_name); ?></div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Ditolak</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($cashRequest->rejection_reason ?: '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                    <div>
                        <strong>Status Kas:</strong>
                        <?php if($dailyReport->closed_at): ?>
                            <span class="badge bg-secondary">Ditutup <?php echo e($dailyReport->closed_at->timezone('Asia/Jakarta')->format('H:i')); ?> WIB</span>
                            <div class="small text-muted mt-1">
                                Uang fisik Rp <?php echo e(number_format($dailyReport->physical_money, 0, ',', '.')); ?>

                                | Selisih Rp <?php echo e(number_format($dailyReport->difference, 0, ',', '.')); ?>

                            </div>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Belum ditutup</span>
                        <?php endif; ?>
                    </div>
                    <?php if(!$dailyReport->closed_at && $dailyReport->status === 'pending'): ?>
                        <form action="<?php echo e(route('teller.daily-reports.close')); ?>" method="POST"
                            class="d-flex flex-wrap align-items-end gap-2"
                            onsubmit="return confirm('Tutup kas harian? Setelah ditutup transaksi hari ini tidak dapat diproses lagi.')">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label for="physical_money" class="form-label mb-1">Uang fisik saat tutup kas</label>
                                <div class="input-group">
                                    <span class="input-group-text">Rp</span>
                                    <input type="text" id="physical_money" name="physical_money"
                                        class="form-control" inputmode="numeric" pattern="[0-9.]*"
                                        value="<?php echo e(old('physical_money', number_format($dailyReport->ending_balance, 0, ',', '.'))); ?>"
                                        required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-danger">Tutup Kas Harian</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="text-end mt-3">
                    <a
                        href="<?php echo e(route('teller.daily-reports.show', $dailyReport->id)); ?>"
                        class="btn btn-outline-primary btn-sm"
                    >
                        Lihat detail laporan
                    </a>
                </div>

            </div>

        </div>

    <?php endif; ?>

</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        ['opening_cash', 'physical_money'].forEach(function (inputId) {
            const moneyInput = document.getElementById(inputId);
            if (!moneyInput) {
                return;
            }

            moneyInput.addEventListener('input', function () {
                const digits = moneyInput.value.replace(/\D/g, '');
                moneyInput.value = digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/teller/dashboard.blade.php ENDPATH**/ ?>