

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5" style="max-width:450px;">

    <div class="card shadow">

        <div class="card-header text-center bg-primary text-white">
            <h4>Mini Bank Login</h4>
            <p class="mb-0">Sistem Informasi Bank Mini</p>
        </div>

        <div class="card-body">

            
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>

            
            <form action="<?php echo e(route('login.authenticate')); ?>" method="POST">

                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="username" class="form-label">
                        Username
                    </label>

                    <input
                        type="text"
                        id="username"
                        name="username"
                        class="form-control"
                        value="<?php echo e(old('username')); ?>"
                        placeholder="Masukkan username"
                        autocomplete="username"
                        required
                        autofocus>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">
                        Password
                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="form-control"
                        placeholder="Masukkan password"
                        autocomplete="current-password"
                        required>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    Login
                </button>

            </form>

            
            <div class="text-center mt-3">
                <a href="<?php echo e(route('password.request')); ?>"
                   class="text-decoration-none">
                    Lupa Password?
                </a>
            </div>

        </div>

        <div class="card-footer text-center text-muted">
            <small>Mini Bank &copy; <?php echo e(date('Y')); ?></small>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/auth/login.blade.php ENDPATH**/ ?>