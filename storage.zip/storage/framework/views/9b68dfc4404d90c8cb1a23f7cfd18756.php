

<?php $__env->startSection('title','Customers'); ?>

<?php $__env->startSection('content'); ?>

<h2>Customer Data</h2>

<hr>

<div class="d-flex justify-content-between align-items-center mb-3">

    <a href="<?php echo e(route('customers.create')); ?>"
       class="btn btn-primary">
        Add Customer
    </a>

    <form action="<?php echo e(route('customers.index')); ?>"
          method="GET"
          class="d-flex">

        <input
            type="text"
            name="keyword"
            class="form-control me-2"
            placeholder="Search..."
            value="<?php echo e(request('keyword')); ?>">

        <button class="btn btn-primary me-2">
            Search
        </button>

        <a href="<?php echo e(route('customers.index')); ?>"
           class="btn btn-secondary">
            Reset
        </a>

    </form>

</div>

<table class="table table-bordered table-hover">

    <thead class="table-dark">

        <tr>

            <th width="60">No</th>
            <th>Account Number</th>
            <th>NIS</th>
            <th>Name</th>
            <th>Class</th>
            <th>Balance</th>
            <th>Status</th>
            <th width="100">QR Code</th>
            <th width="200">Action</th>

        </tr>

    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

            <td>
                <?php echo e(($customers->currentPage() - 1) * $customers->perPage() + $loop->iteration); ?>

            </td>

            <td><?php echo e($customer->account_number); ?></td>

            <td><?php echo e($customer->nis); ?></td>

            <td><?php echo e($customer->name); ?></td>

            <td><?php echo e($customer->class); ?></td>

            <td>
                Rp <?php echo e(number_format($customer->balance,0,',','.')); ?>

            </td>

            <td><span class="badge bg-success">Active</span></td>

            <td class="text-center">

                <?php if($customer->qrcode): ?>

                    <img
                        src="<?php echo e(asset('qrcode/'.$customer->qrcode)); ?>"
                        width="70">

                <?php else: ?>

                    -

                <?php endif; ?>

            </td>

            <td>

                <a href="<?php echo e(route('customers.edit',$customer->id)); ?>"
                   class="btn btn-warning btn-sm">

                    Edit

                </a>

                <form
                    action="<?php echo e(route('customers.status',$customer->id)); ?>"
                    method="POST"
                    class="d-inline">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <input type="hidden" name="status" value="nonaktif">

                    <button class="btn btn-secondary btn-sm"
                        onclick="return confirm('Nonaktifkan customer ini?')">
                        Deactivate

                    </button>

                </form>

            </td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>

            <td colspan="9" class="text-center">

                No customer data available.

            </td>

        </tr>

    <?php endif; ?>

    </tbody>

</table>

<div class="d-flex justify-content-center">

    <?php echo e($customers->links()); ?>


</div>

<hr class="my-5">

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Customer Belum Aktif</h3>
    <span class="badge bg-danger text-white"><?php echo e($inactiveCustomers->total()); ?></span>
</div>

<p class="text-muted">
    Admin dapat mengaktifkan customer jika saldo minimal Rp 10.000. Customer dengan saldo di bawah batas tersebut perlu menabung terlebih dahulu.
</p>

<table class="table table-bordered table-hover">
    <thead class="table-dark">
        <tr>
            <th>No</th>
            <th>Account Number</th>
            <th>NIS</th>
            <th>Name</th>
            <th>Class</th>
            <th>Balance</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $inactiveCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e(($inactiveCustomers->currentPage() - 1) * $inactiveCustomers->perPage() + $loop->iteration); ?></td>
            <td><?php echo e($customer->account_number); ?></td>
            <td><?php echo e($customer->nis); ?></td>
            <td><?php echo e($customer->name); ?></td>
            <td><?php echo e($customer->class); ?></td>
            <td>Rp <?php echo e(number_format($customer->balance,0,',','.')); ?></td>
            <td><span class="badge bg-secondary">Inactive</span></td>
            <td>
                <a href="<?php echo e(route('customers.edit',$customer->id)); ?>" class="btn btn-warning btn-sm">
                    Edit
                </a>
                <?php if((float) $customer->balance >= 10000): ?>
                    <form action="<?php echo e(route('customers.status',$customer->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="status" value="aktif">
                        <button class="btn btn-success btn-sm"
                            onclick="return confirm('Aktifkan customer ini?')">
                            Activate
                        </button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-success btn-sm" disabled
                        title="Saldo harus minimal Rp 10.000 untuk aktivasi">
                        Activate
                    </button>
                    <span class="small text-muted">Saldo harus minimal Rp 10.000</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="8" class="text-center">Tidak ada customer nonaktif.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

<div class="d-flex justify-content-center">
    <?php echo e($inactiveCustomers->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/customers/index.blade.php ENDPATH**/ ?>