

<?php $__env->startSection('title', 'Create Customer'); ?>

<?php $__env->startSection('content'); ?>

<h2>Create Customer</h2>

<hr>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="card shadow">

    <div class="card-body">

        <form action="<?php echo e(route('customers.store')); ?>" method="POST">

            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label>Account Number</label>

                <input
                    type="text"
                    name="account_number"
                    class="form-control"
                    value="<?php echo e($accountNumber); ?>"
                    readonly>
            </div>

            <div class="mb-3">
                <label>NIS</label>

                <input
                    type="text"
                    name="nis"
                    class="form-control"
                    required>
            </div>

            <div class="mb-3">
                <label>Customer Name</label>

                <input
                    type="text"
                    name="name"
                    class="form-control"
                    required>
            </div>

            <div class="mb-3">
                <label for="email">Email</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    class="form-control"
                    value="<?php echo e(old('email')); ?>"
                    maxlength="255"
                    autocomplete="email"
                    required>

                <small class="text-muted">
                    Email ini digunakan untuk menerima kode OTP saat lupa password.
                </small>
            </div>

            <div class="mb-3">
                <label>Class</label>

                <input
                    type="text"
                    name="class"
                    class="form-control"
                    required>
            </div>

            <div class="mb-3">
                <label>Location</label>

                <textarea
                    name="location"
                    class="form-control"
                    rows="3"
                    required></textarea>
            </div>

            <div class="mb-3">
                <label>Telephone Number</label>

                <input
                    type="text"
                    name="telephone_number"
                    class="form-control"
                    required>
            </div>

            <div class="mb-3">
                <label for="password">Password Login</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    class="form-control"
                    minlength="4"
                    autocomplete="new-password"
                    required>

                <small class="text-muted">
                    Password ini digunakan untuk login customer dan berbeda dari PIN transaksi.
                    Minimal 4 karakter.
                </small>
            </div>

            <div class="mb-3">
                <label>PIN</label>

                <input
                    type="password"
                    name="pin"
                    class="form-control"
                    inputmode="numeric"
                    pattern="[0-9]{6}"
                    minlength="6"
                    maxlength="6"
                    autocomplete="new-password"
                    required>

                <small class="text-muted">
                    PIN harus terdiri dari 6 angka.
                </small>
            </div>

            <div class="alert alert-info">
                Customer baru dibuat dalam status nonaktif dengan saldo Rp 0.
                Akun akan aktif setelah setoran pertama minimal Rp 10.000.
            </div>

            <button class="btn btn-success">
                Save Customer
            </button>

            <a href="<?php echo e(route('customers.index')); ?>"
               class="btn btn-secondary">
                Back
            </a>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ukk_bank_mini\resources\views/customers/create.blade.php ENDPATH**/ ?>